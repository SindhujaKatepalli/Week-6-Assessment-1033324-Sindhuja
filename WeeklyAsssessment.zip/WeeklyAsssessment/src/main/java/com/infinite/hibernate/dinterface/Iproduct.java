package com.infinite.hibernate.dinterface;

import com.infinite.hibernate.pojo.Product;

public interface Iproduct {
	public void create(String Productname, float price, int qunatity, float total, Product pr);

	public Product update(Product p);

	public void delete(int Productid);

}
