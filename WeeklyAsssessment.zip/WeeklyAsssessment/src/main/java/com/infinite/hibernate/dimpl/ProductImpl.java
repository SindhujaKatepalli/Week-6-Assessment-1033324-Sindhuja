package com.infinite.hibernate.dimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infinite.hibernate.dinterface.Iproduct;
import com.infinite.hibernate.pojo.Product;
import com.infinite.hibernateDaohelper.DaoHelper;

/**
 * @author sindhujak
 *
 */
public class ProductImpl implements Iproduct{
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;
		private Configuration con;
		private Transaction t;
			public void saveData(Product e) {
				con = new Configuration().configure("hibernate.cfg.xml");
				sessionFactoryObj = con.buildSessionFactory();
				sessionObj = sessionFactoryObj.openSession();
				t = sessionObj.beginTransaction();
				sessionObj.save(e);
				t.commit();
			}

		public void create(String Productname, float price, int qunatity, float total, Product pr) {
				// TODO Auto-generated method stub
	// Getting Session Object From SessionFactory

	try {
		sessionObj = DaoHelper.buildSessionFactory().openSession();
		// Getting Transaction Object From Session Object
		sessionObj.beginTransaction();
		Product p = (Product) sessionObj.get(Product.class,pr.getProductid());
		p.setName(p.getName());
		p.setPrice(p.getPrice());
		p.setQuantity(p.getQuantity());
		p.setTotal(p.getTotal());
		sessionObj.update(p);
		sessionObj.save(p);
		sessionObj.getTransaction().commit();
	} catch (Exception ex) {
		ex.printStackTrace();
	} finally {
		try {
			sessionObj.close();
		} catch (Exception e11) {
			e11.printStackTrace();
		}
	}
}
		
		public void delete(int Productid) {
			// TODO Auto-generated method stub
			Product p = (Product) sessionFactoryObj.getCurrentSession().load(
					Product.class, Productid);
	        if (null != p) {
	            this.sessionFactoryObj.getCurrentSession().delete(p);
	        } 
			
		}

		public Product update(Product p) {
			// TODO Auto-generated method stub
			 sessionFactoryObj.getCurrentSession().update(p);
		        return p;
		}
}
