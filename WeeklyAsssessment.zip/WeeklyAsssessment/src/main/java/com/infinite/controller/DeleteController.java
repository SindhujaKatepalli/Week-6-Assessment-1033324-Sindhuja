package com.infinite.controller;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.hibernate.dimpl.ProductImpl;
import com.infinite.hibernate.pojo.Product;

public class DeleteController {
	private static final Logger logger= Logger.getLogger(DeleteController.class);
	private ApplicationContext con;
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String insert(@ModelAttribute("bean") Product e,Model m){
		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		ProductImpl obj=con.getBean("dao",ProductImpl.class);
		logger.info("i");
		return "deletesuccess";	
	}
}
